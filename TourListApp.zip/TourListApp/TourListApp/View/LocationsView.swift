//
//  LocationsView.swift
//  TourListApp
//
//  Created by Sunny Hwang on 2023/08/05.
//

import SwiftUI
import MapKit

struct LocationsView: View {
    @EnvironmentObject var viewModel: LocationsViewModel
    @State var sheetLocation: Location? = nil
    var body: some View {
        ZStack {
            MapLayer
        }
    }
}

extension LocationsView {
    var MapLayer: some View {
        Map(coordinateRegion: $viewModel.mapRegion, annotationItems: viewModel.locations) { location in
            MapAnnotation(coordinate: location.coordinates) {
                
            }
        }
    }
}

struct LocationsView_Previews: PreviewProvider {
    static var previews: some View {
        LocationsView()
    }
}
