//
//  LocaationsViewModel.swift
//  TourListApp
//
//  Created by Sunny Hwang on 2023/08/05.
//

import Foundation
import MapKit
import SwiftUI

class LocationsViewModel: ObservableObject {
    @Published var locations: [Location]
    @Published var mapLocation: Location
    @Published var mapRegion = MKCoordinateRegion()
    @Published var mapSpan = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
    @Published var showLocationList: Bool = false
    @Published var sheetLocation: Location? = nil
    init() {
        var locations = LocationDataService.locations
        let landmarks: [Landmark] = LocationDataService.load("landmarkData.json")
        locations.append(contentsOf: landmarks.getLocations())
        self.locations = locations
        self.mapLocation = locations.first!
    }
    func updateMapRegion(location: Location) {
        withAnimation(.easeInOut) {
            mapRegion = MKCoordinateRegion(center: location.coordinates, span: mapSpan)
        }
    }
    func toggleLocationList() {
        withAnimation(.easeInOut) {
            showLocationList.toggle()
        }
    }
    func showNextLocation(location: Location) {
        withAnimation(.easeInOut) {
            mapLocation = location
            showLocationList = false
        }
    }
    func nextButtonPressed() {
        guard let currentLocation = locations.firstIndex(where:{ mapLocation == $0}) else { return }
        var nextLocation = currentLocation + 1
        guard locations.indices.contains(nextLocation) else {
            guard let firstLocation = locations.first else {
                return }
            showNextLocation(location: firstLocation)
            return
        }
        showNextLocation(location: locations[nextLocation])
    }
}
