//
//  TourListAppApp.swift
//  TourListApp
//
//  Created by Sunny Hwang on 2023/08/05.
//

import SwiftUI

@main
struct TourListAppApp: App {
    var body: some Scene {
        let viewModel = LocationsViewModel()
        WindowGroup {
            ContentView()
                .environmentObject(viewModel)
        }
    }
}
